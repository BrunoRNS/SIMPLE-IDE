#include "libbb.h"
#include "mingw_ip.h"

int FAST_FUNC inet_aton(const char *cp, struct in_addr *inp)
{
	unsigned long val = inet_addr(cp);

	if (val == INADDR_NONE)
		return 0;
	inp->S_un.S_addr = val;
	return 1;
}

void init_winsock(void)
{
	WSADATA wsa;
	static int initialized = 0;

	if (initialized)
		return;

	if (WSAStartup(MAKEWORD(2,2), &wsa))
		bb_error_msg_and_die("WSAStartup failed, error %d", WSAGetLastError());

	atexit((void(*)(void)) WSACleanup);
	initialized = 1;
}

#undef inet_ntop
const char *mingw_inet_ntop (int af, const void *__restrict addr, char *__restrict buf, socklen_t buflen) {
	/* There is an inet_ntop function, but only in Windows Vista */
	union {
		struct sockaddr sa;
		struct sockaddr_in sin;
#if ENABLE_FEATURE_IPV6
		struct sockaddr_in6 sin6;
#endif
	} u;
	DWORD buflen_dw = buflen;
	memset(&u, 0, sizeof(u));
	u.sa.sa_family = af;

	switch (af) {
	case AF_INET:
		memcpy(&u.sin.sin_addr, addr, sizeof(u.sin.sin_addr));
		break;
#if ENABLE_FEATURE_IPV6
	case AF_INET6:
		memcpy(&u.sin6.sin6_addr, addr, sizeof(u.sin6.sin6_addr));
		break;
#endif
	default:
		bb_error_msg_and_die("inet_ntop: unsupported family: %d", af);
	}

	init_winsock();
	if (WSAAddressToStringA(&u.sa, sizeof(u), NULL, buf, &buflen_dw) != 0) {
		errno = WSAGetLastError();
		return NULL;
	}
	return buf;
}

#undef gethostname
int FAST_FUNC mingw_gethostname(char *name, int namelen)
{
	init_winsock();
	return gethostname(name, namelen);
}

#undef gethostbyaddr
struct hostent * FAST_FUNC
mingw_gethostbyaddr(const void *addr, socklen_t len, int type)
{
	init_winsock();
	return gethostbyaddr(addr, len, type);
}

#undef getaddrinfo
int FAST_FUNC mingw_getaddrinfo(const char *node, const char *service,
				const struct addrinfo *hints, struct addrinfo **res)
{
	init_winsock();
	return getaddrinfo(node, service, hints, res);
}

#undef getnameinfo
int FAST_FUNC mingw_getnameinfo(const struct sockaddr *sa, socklen_t salen, char *host, int hostsz, char *svc, int svcsz, int flags)
{
	init_winsock();
	return getnameinfo(sa, salen, host, hostsz, svc, svcsz, flags);
}

int FAST_FUNC mingw_socket(int domain, int type, int protocol)
{
	static char include_overlapped = 0;
	int sockfd;
	SOCKET s;

	if (domain == MINGW_INCLUDE_OVERLAPPED_ONCE) {
		include_overlapped = 1;
		return 0;
	}

	init_winsock();
	s = WSASocket(domain, type, protocol, NULL, 0, include_overlapped ? WSA_FLAG_OVERLAPPED : 0);
	include_overlapped = 0;
	if (s == INVALID_SOCKET) {
		/*
		 * WSAGetLastError() values are regular BSD error codes
		 * biased by WSABASEERR.
		 * However, strerror() does not know about networking
		 * specific errors, which are values beginning at 38 or so.
		 * Therefore, we choose to leave the biased error code
		 * in errno so that _if_ someone looks up the code somewhere,
		 * then it is at least the number that are usually listed.
		 */
		errno = WSAGetLastError();
		return -1;
	}
	/* convert into a file descriptor */
	if ((sockfd = _open_osfhandle((intptr_t)s, O_RDWR|O_BINARY)) < 0) {
		closesocket(s);
		bb_error_msg("unable to make a socket file descriptor: %s",
			     strerror(errno));
		return -1;
	}
	return sockfd;
}

#undef connect
int FAST_FUNC mingw_connect(int sockfd, const struct sockaddr *sa, size_t sz)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	return connect(s, sa, sz);
}

#undef bind
int FAST_FUNC mingw_bind(int sockfd, struct sockaddr *sa, size_t sz)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	return bind(s, sa, sz);
}

#undef sendto
int FAST_FUNC mingw_sendto(int sockfd, const char *buf, int len, int flags, const struct sockaddr *to, int tolen)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	int res = sendto(s, buf, len, flags, to, tolen);
	if (res < 0)
		errno = WSAGetLastError();
	return res;
}

#undef recv
int FAST_FUNC mingw_recv(int sockfd, char *buf, int len, int flags)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	int res = recv(s, buf, len, flags);
	if (res < 0)
		errno = WSAGetLastError();
	return res;
}

#undef recvfrom
int FAST_FUNC mingw_recvfrom(int sockfd, char *buf, int len, int flags, struct sockaddr *from, int *fromlen)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	int res = recvfrom(s, buf, len, flags, from, fromlen);
	if (res < 0)
		errno = WSAGetLastError();
	return res;
}

int recvmsg(int fd, LPWSAMSG msg, int flags) {
	DWORD recv_length;
	LPFN_WSARECVMSG lpWSARecvMsg = NULL;
	GUID g = WSAID_WSARECVMSG;
	SOCKET s = (SOCKET)_get_osfhandle(fd);

	/* Look up the WSARecvMsg function for the socket */
	if (WSAIoctl(s, SIO_GET_EXTENSION_FUNCTION_POINTER,
			&g, sizeof(g),
			&lpWSARecvMsg, sizeof(lpWSARecvMsg),
			&recv_length, NULL, NULL) != 0) {
		/* WSARecvMsg is not available. Don't do any control messages */
		msg->msg_controllen = 0;
		return mingw_recvfrom(fd,
			msg->msg_iov->iov_base, msg->msg_iov->iov_len,
			flags,
			msg->msg_name, &msg->msg_namelen);
	}

	msg->msg_flags = flags;

	if (lpWSARecvMsg(s, msg, &recv_length, NULL, NULL) != 0) {
		errno = WSAGetLastError();
		return -1;
	}
	return recv_length;
}

#undef setsockopt
int FAST_FUNC
mingw_setsockopt(int sockfd, int lvl, int optname, void *optval, int optlen)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	return setsockopt(s, lvl, optname, (const char*)optval, optlen);
}

#undef shutdown
int FAST_FUNC mingw_shutdown(int sockfd, int how)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	return shutdown(s, how);
}

#undef listen
int FAST_FUNC mingw_listen(int sockfd, int backlog)
{
	SOCKET s = (SOCKET)_get_osfhandle(sockfd);
	return listen(s, backlog);
}

#undef accept
int FAST_FUNC mingw_accept(int sockfd1, struct sockaddr *sa, socklen_t *sz)
{
	int sockfd2;

	SOCKET s1 = (SOCKET)_get_osfhandle(sockfd1);
	SOCKET s2 = accept(s1, sa, sz);

	/* convert into a file descriptor */
	if ((sockfd2 = _open_osfhandle((intptr_t)s2, O_RDWR|O_BINARY)) < 0) {
		int err = errno;
		closesocket(s2);
		bb_error_msg("unable to make a socket file descriptor: %s",
			strerror(err));
		return -1;
	}
	return sockfd2;
}

#undef getpeername
int FAST_FUNC mingw_getpeername(int fd, struct sockaddr *sa, socklen_t *sz)
{
	SOCKET sock;

	init_winsock();
	sock = (SOCKET)_get_osfhandle(fd);
	if (sock == INVALID_SOCKET) {
		errno = EBADF;
		return -1;
	}
	return getpeername(sock, sa, sz);
}
