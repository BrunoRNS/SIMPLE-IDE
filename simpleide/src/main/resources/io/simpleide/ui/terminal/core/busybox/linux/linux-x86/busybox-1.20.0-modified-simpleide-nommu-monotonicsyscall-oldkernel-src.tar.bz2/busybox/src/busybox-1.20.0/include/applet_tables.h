/* This is a generated file, don't edit */

#define NUM_APPLETS 351

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"acpid" "\0"
"add-shell" "\0"
"addgroup" "\0"
"adduser" "\0"
"adjtimex" "\0"
"arp" "\0"
"arping" "\0"
"awk" "\0"
"base64" "\0"
"basename" "\0"
"beep" "\0"
"blkid" "\0"
"blockdev" "\0"
"bootchartd" "\0"
"brctl" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"bzip2" "\0"
"cal" "\0"
"cat" "\0"
"catv" "\0"
"chat" "\0"
"chattr" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chpasswd" "\0"
"chpst" "\0"
"chroot" "\0"
"chrt" "\0"
"chvt" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"comm" "\0"
"conspy" "\0"
"cp" "\0"
"cpio" "\0"
"crond" "\0"
"crontab" "\0"
"cryptpw" "\0"
"cttyhack" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"depmod" "\0"
"devmem" "\0"
"df" "\0"
"dhcprelay" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsd" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"du" "\0"
"dumpkmap" "\0"
"dumpleases" "\0"
"echo" "\0"
"ed" "\0"
"egrep" "\0"
"eject" "\0"
"env" "\0"
"envdir" "\0"
"envuidgid" "\0"
"ether-wake" "\0"
"expand" "\0"
"expr" "\0"
"fakeidentd" "\0"
"false" "\0"
"fbset" "\0"
"fbsplash" "\0"
"fdflush" "\0"
"fdformat" "\0"
"fdisk" "\0"
"fgconsole" "\0"
"fgrep" "\0"
"find" "\0"
"findfs" "\0"
"flock" "\0"
"fold" "\0"
"free" "\0"
"freeramdisk" "\0"
"fsck" "\0"
"fsck.minix" "\0"
"fsync" "\0"
"ftpd" "\0"
"ftpget" "\0"
"ftpput" "\0"
"fuser" "\0"
"getopt" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"hd" "\0"
"hdparm" "\0"
"head" "\0"
"hexdump" "\0"
"hostid" "\0"
"hostname" "\0"
"httpd" "\0"
"hush" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifenslave" "\0"
"ifplugd" "\0"
"ifup" "\0"
"inetd" "\0"
"init" "\0"
"insmod" "\0"
"install" "\0"
"ionice" "\0"
"iostat" "\0"
"ip" "\0"
"ipaddr" "\0"
"ipcalc" "\0"
"ipcrm" "\0"
"ipcs" "\0"
"iplink" "\0"
"iproute" "\0"
"iprule" "\0"
"iptunnel" "\0"
"kbd_mode" "\0"
"kill" "\0"
"killall" "\0"
"killall5" "\0"
"klogd" "\0"
"last" "\0"
"less" "\0"
"linux32" "\0"
"linux64" "\0"
"linuxrc" "\0"
"ln" "\0"
"loadfont" "\0"
"loadkmap" "\0"
"logger" "\0"
"login" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"lpd" "\0"
"lpq" "\0"
"lpr" "\0"
"ls" "\0"
"lsattr" "\0"
"lsmod" "\0"
"lsof" "\0"
"lspci" "\0"
"lsusb" "\0"
"lzcat" "\0"
"lzma" "\0"
"lzop" "\0"
"lzopcat" "\0"
"makedevs" "\0"
"makemime" "\0"
"man" "\0"
"md5sum" "\0"
"mdev" "\0"
"mesg" "\0"
"microcom" "\0"
"mkdir" "\0"
"mkdosfs" "\0"
"mke2fs" "\0"
"mkfifo" "\0"
"mkfs.ext2" "\0"
"mkfs.minix" "\0"
"mkfs.vfat" "\0"
"mknod" "\0"
"mkpasswd" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mountpoint" "\0"
"mpstat" "\0"
"mt" "\0"
"mv" "\0"
"nameif" "\0"
"nanddump" "\0"
"nandwrite" "\0"
"nbd-client" "\0"
"nc" "\0"
"netstat" "\0"
"nice" "\0"
"nmeter" "\0"
"nohup" "\0"
"nslookup" "\0"
"ntpd" "\0"
"od" "\0"
"openvt" "\0"
"passwd" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"ping" "\0"
"ping6" "\0"
"pipe_progress" "\0"
"pivot_root" "\0"
"pkill" "\0"
"pmap" "\0"
"popmaildir" "\0"
"poweroff" "\0"
"powertop" "\0"
"printenv" "\0"
"printf" "\0"
"ps" "\0"
"pscan" "\0"
"pstree" "\0"
"pwd" "\0"
"pwdx" "\0"
"raidautorun" "\0"
"rdate" "\0"
"rdev" "\0"
"readahead" "\0"
"readlink" "\0"
"readprofile" "\0"
"realpath" "\0"
"reboot" "\0"
"reformime" "\0"
"remove-shell" "\0"
"renice" "\0"
"reset" "\0"
"resize" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"rpm" "\0"
"rpm2cpio" "\0"
"rtcwake" "\0"
"run-parts" "\0"
"runlevel" "\0"
"runsv" "\0"
"runsvdir" "\0"
"rx" "\0"
"script" "\0"
"scriptreplay" "\0"
"sed" "\0"
"sendmail" "\0"
"seq" "\0"
"setarch" "\0"
"setconsole" "\0"
"setfont" "\0"
"setkeycodes" "\0"
"setlogcons" "\0"
"setserial" "\0"
"setsid" "\0"
"setuidgid" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha512sum" "\0"
"showkey" "\0"
"slattach" "\0"
"sleep" "\0"
"smemcap" "\0"
"softlimit" "\0"
"sort" "\0"
"split" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"su" "\0"
"sulogin" "\0"
"sum" "\0"
"sv" "\0"
"svlogd" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tac" "\0"
"tail" "\0"
"tar" "\0"
"tcpsvd" "\0"
"tee" "\0"
"telnet" "\0"
"telnetd" "\0"
"test" "\0"
"tftp" "\0"
"tftpd" "\0"
"time" "\0"
"timeout" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"traceroute" "\0"
"traceroute6" "\0"
"true" "\0"
"tty" "\0"
"ttysize" "\0"
"tunctl" "\0"
"ubiattach" "\0"
"ubidetach" "\0"
"ubimkvol" "\0"
"ubirmvol" "\0"
"ubirsvol" "\0"
"ubiupdatevol" "\0"
"udhcpc" "\0"
"udhcpd" "\0"
"udpsvd" "\0"
"umount" "\0"
"uname" "\0"
"unexpand" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unlzma" "\0"
"unlzop" "\0"
"unxz" "\0"
"unzip" "\0"
"uptime" "\0"
"users" "\0"
"usleep" "\0"
"uudecode" "\0"
"uuencode" "\0"
"vconfig" "\0"
"vi" "\0"
"vlock" "\0"
"volname" "\0"
"wall" "\0"
"watch" "\0"
"watchdog" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
"zcip" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
acpid_main,
add_remove_shell_main,
addgroup_main,
adduser_main,
adjtimex_main,
arp_main,
arping_main,
awk_main,
base64_main,
basename_main,
beep_main,
blkid_main,
blockdev_main,
bootchartd_main,
brctl_main,
bunzip2_main,
bunzip2_main,
bzip2_main,
cal_main,
cat_main,
catv_main,
chat_main,
chattr_main,
chgrp_main,
chmod_main,
chown_main,
chpasswd_main,
chpst_main,
chroot_main,
chrt_main,
chvt_main,
cksum_main,
clear_main,
cmp_main,
comm_main,
conspy_main,
cp_main,
cpio_main,
crond_main,
crontab_main,
cryptpw_main,
cttyhack_main,
cut_main,
date_main,
dc_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
modprobe_main,
devmem_main,
df_main,
dhcprelay_main,
diff_main,
dirname_main,
dmesg_main,
dnsd_main,
hostname_main,
dos2unix_main,
du_main,
dumpkmap_main,
dumpleases_main,
echo_main,
ed_main,
grep_main,
eject_main,
env_main,
chpst_main,
chpst_main,
ether_wake_main,
expand_main,
expr_main,
fakeidentd_main,
false_main,
fbset_main,
fbsplash_main,
freeramdisk_main,
fdformat_main,
fdisk_main,
fgconsole_main,
grep_main,
find_main,
findfs_main,
flock_main,
fold_main,
free_main,
freeramdisk_main,
fsck_main,
fsck_minix_main,
fsync_main,
ftpd_main,
ftpgetput_main,
ftpgetput_main,
fuser_main,
getopt_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
hexdump_main,
hdparm_main,
head_main,
hexdump_main,
hostid_main,
hostname_main,
httpd_main,
hush_main,
hwclock_main,
id_main,
ifconfig_main,
ifupdown_main,
ifenslave_main,
ifplugd_main,
ifupdown_main,
inetd_main,
init_main,
modprobe_main,
install_main,
ionice_main,
iostat_main,
ip_main,
ipaddr_main,
ipcalc_main,
ipcrm_main,
ipcs_main,
iplink_main,
iproute_main,
iprule_main,
iptunnel_main,
kbd_mode_main,
kill_main,
kill_main,
kill_main,
klogd_main,
last_main,
less_main,
setarch_main,
setarch_main,
init_main,
ln_main,
loadfont_main,
loadkmap_main,
logger_main,
login_main,
logname_main,
logread_main,
losetup_main,
lpd_main,
lpqr_main,
lpqr_main,
ls_main,
lsattr_main,
modprobe_main,
lsof_main,
lspci_main,
lsusb_main,
unlzma_main,
unlzma_main,
lzop_main,
lzop_main,
makedevs_main,
makemime_main,
man_main,
md5_sha1_sum_main,
mdev_main,
mesg_main,
microcom_main,
mkdir_main,
mkfs_vfat_main,
mkfs_ext2_main,
mkfifo_main,
mkfs_ext2_main,
mkfs_minix_main,
mkfs_vfat_main,
mknod_main,
cryptpw_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mountpoint_main,
mpstat_main,
mt_main,
mv_main,
nameif_main,
nandwrite_main,
nandwrite_main,
nbdclient_main,
nc_main,
netstat_main,
nice_main,
nmeter_main,
nohup_main,
nslookup_main,
ntpd_main,
od_main,
openvt_main,
passwd_main,
patch_main,
pgrep_main,
pidof_main,
ping_main,
ping6_main,
pipe_progress_main,
pivot_root_main,
pgrep_main,
pmap_main,
popmaildir_main,
halt_main,
powertop_main,
printenv_main,
printf_main,
ps_main,
pscan_main,
pstree_main,
pwd_main,
pwdx_main,
raidautorun_main,
rdate_main,
rdev_main,
readahead_main,
readlink_main,
readprofile_main,
realpath_main,
halt_main,
reformime_main,
add_remove_shell_main,
renice_main,
reset_main,
resize_main,
rev_main,
rm_main,
rmdir_main,
modprobe_main,
route_main,
rpm_main,
rpm2cpio_main,
rtcwake_main,
run_parts_main,
runlevel_main,
runsv_main,
runsvdir_main,
rx_main,
script_main,
scriptreplay_main,
sed_main,
sendmail_main,
seq_main,
setarch_main,
setconsole_main,
setfont_main,
setkeycodes_main,
setlogcons_main,
setserial_main,
setsid_main,
chpst_main,
hush_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
showkey_main,
slattach_main,
sleep_main,
smemcap_main,
chpst_main,
sort_main,
split_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
su_main,
sulogin_main,
sum_main,
sv_main,
svlogd_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tac_main,
tail_main,
tar_main,
tcpudpsvd_main,
tee_main,
telnet_main,
telnetd_main,
test_main,
tftp_main,
tftpd_main,
time_main,
timeout_main,
top_main,
touch_main,
tr_main,
traceroute_main,
traceroute6_main,
true_main,
tty_main,
ttysize_main,
tunctl_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
udhcpc_main,
udhcpd_main,
tcpudpsvd_main,
umount_main,
uname_main,
expand_main,
uniq_main,
dos2unix_main,
unlzma_main,
lzop_main,
unxz_main,
unzip_main,
uptime_main,
who_main,
usleep_main,
uudecode_main,
uuencode_main,
vconfig_main,
vi_main,
vlock_main,
volname_main,
wall_main,
watch_main,
watchdog_main,
wc_main,
wget_main,
which_main,
who_main,
whoami_main,
whois_main,
xargs_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
zcip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x000b,
0x0015,
0x001e,
0x0026,
0x002f,
0x0033,
0x003a,
0x003e,
0x0045,
0x004e,
0x0053,
0x0059,
0x0062,
0x006d,
0x0073,
0x007b,
0x0081,
0x0087,
0x008b,
0x008f,
0x0094,
0x0099,
0x00a0,
0x00a6,
0x00ac,
0x00b2,
0x00bb,
0x00c1,
0x00c8,
0x00cd,
0x00d2,
0x00d8,
0x00de,
0x00e2,
0x00e7,
0x00ee,
0x00f1,
0x00f6,
0x80fc,
0x0104,
0x010c,
0x0115,
0x0119,
0x011e,
0x0121,
0x0124,
0x012e,
0x0137,
0x013f,
0x0146,
0x014d,
0x0150,
0x015a,
0x015f,
0x0167,
0x016d,
0x0172,
0x0180,
0x0189,
0x018c,
0x0195,
0x01a0,
0x01a5,
0x01a8,
0x01ae,
0x01b4,
0x01b8,
0x01bf,
0x01c9,
0x01d4,
0x01db,
0x01e0,
0x01eb,
0x01f1,
0x01f7,
0x0200,
0x0208,
0x0211,
0x0217,
0x0221,
0x0227,
0x422c,
0x0233,
0x0239,
0x023e,
0x0243,
0x024f,
0x0254,
0x025f,
0x0265,
0x026a,
0x0271,
0x0278,
0x027e,
0x0285,
0x028b,
0x0290,
0x0297,
0x029e,
0x02a3,
0x02a8,
0x02ab,
0x02b2,
0x02b7,
0x02bf,
0x02c6,
0x02cf,
0x02d5,
0x02da,
0x02e2,
0x02e5,
0x02ee,
0x02f5,
0x02ff,
0x0307,
0x030c,
0x0312,
0x0317,
0x031e,
0x0326,
0x032d,
0x0334,
0x0337,
0x033e,
0x0345,
0x034b,
0x0350,
0x0357,
0x035f,
0x0366,
0x036f,
0x0378,
0x037d,
0x0385,
0x038e,
0x0394,
0x0399,
0x039e,
0x03a6,
0x03ae,
0x03b6,
0x03b9,
0x03c2,
0x03cb,
0x83d2,
0x03d8,
0x03e0,
0x03e8,
0x03f0,
0x03f4,
0x03f8,
0x03fc,
0x03ff,
0x0406,
0x040c,
0x0411,
0x0417,
0x041d,
0x0423,
0x0428,
0x042d,
0x0435,
0x043e,
0x0447,
0x044b,
0x0452,
0x0457,
0x045c,
0x0465,
0x046b,
0x0473,
0x047a,
0x0481,
0x048b,
0x0496,
0x04a0,
0x04a6,
0x04af,
0x04b6,
0x04bd,
0x04c5,
0x04ce,
0x44d3,
0x04d9,
0x04e4,
0x04eb,
0x04ee,
0x04f1,
0x04f8,
0x0501,
0x050b,
0x0516,
0x0519,
0x0521,
0x0526,
0x052d,
0x0533,
0x053c,
0x0541,
0x0544,
0x854b,
0x0552,
0x0558,
0x055e,
0x4564,
0x4569,
0x056f,
0x057d,
0x0588,
0x058e,
0x0593,
0x059e,
0x05a7,
0x05b0,
0x05b9,
0x05c0,
0x05c3,
0x05c9,
0x05d0,
0x05d4,
0x05d9,
0x05e5,
0x05eb,
0x05f0,
0x05fa,
0x0603,
0x060f,
0x0618,
0x061f,
0x0629,
0x0636,
0x063d,
0x0643,
0x064a,
0x064e,
0x0651,
0x0657,
0x065d,
0x0663,
0x0667,
0x0670,
0x0678,
0x0682,
0x068b,
0x0691,
0x069a,
0x069d,
0x06a4,
0x06b1,
0x06b5,
0x06be,
0x06c2,
0x06ca,
0x06d5,
0x06dd,
0x06e9,
0x06f4,
0x06fe,
0x0705,
0x070f,
0x0712,
0x071a,
0x0724,
0x072e,
0x0736,
0x073f,
0x0745,
0x074d,
0x0757,
0x075c,
0x0762,
0x0774,
0x0779,
0x0781,
0x8786,
0x0789,
0x0791,
0x0795,
0x0798,
0x079f,
0x07a7,
0x07ae,
0x07ba,
0x07bf,
0x07c6,
0x07ce,
0x07d2,
0x07d7,
0x07db,
0x07e2,
0x07e6,
0x07ed,
0x07f5,
0x07fa,
0x07ff,
0x0805,
0x080a,
0x0812,
0x0816,
0x081c,
0x481f,
0x482a,
0x0836,
0x083b,
0x083f,
0x0847,
0x084e,
0x0858,
0x0862,
0x086b,
0x0874,
0x087d,
0x088a,
0x0891,
0x0898,
0x089f,
0x08a6,
0x08ac,
0x08b5,
0x08ba,
0x08c3,
0x08ca,
0x08d1,
0x08d6,
0x08dc,
0x08e3,
0x08e9,
0x08f0,
0x08f9,
0x0902,
0x090a,
0x890d,
0x0913,
0x891b,
0x0920,
0x0926,
0x092f,
0x0932,
0x0937,
0x093d,
0x0941,
0x0948,
0x094e,
0x0954,
0x0957,
0x095d,
0x0961,
0x0966,
};

const uint8_t applet_install_loc[] ALIGN1 = {
0x33,
0x32,
0x11,
0x22,
0x33,
0x31,
0x23,
0x22,
0x34,
0x33,
0x13,
0x31,
0x11,
0x11,
0x34,
0x34,
0x33,
0x33,
0x13,
0x11,
0x34,
0x13,
0x13,
0x13,
0x13,
0x21,
0x12,
0x34,
0x13,
0x14,
0x33,
0x31,
0x11,
0x31,
0x33,
0x33,
0x33,
0x14,
0x24,
0x31,
0x32,
0x31,
0x32,
0x33,
0x22,
0x12,
0x34,
0x33,
0x21,
0x31,
0x11,
0x32,
0x32,
0x33,
0x41,
0x21,
0x23,
0x22,
0x23,
0x24,
0x32,
0x11,
0x11,
0x31,
0x13,
0x11,
0x31,
0x31,
0x23,
0x33,
0x11,
0x10,
0x24,
0x13,
0x23,
0x42,
0x33,
0x11,
0x32,
0x33,
0x33,
0x31,
0x12,
0x32,
0x32,
0x13,
0x22,
0x23,
0x22,
0x31,
0x12,
0x22,
0x11,
0x11,
0x11,
0x42,
0x44,
0x13,
0x31,
0x33,
0x34,
0x33,
0x33,
0x11,
0x11,
0x32,
0x43,
0x12,
0x31,
0x31,
0x13,
0x23,
0x44,
0x33,
0x34,
0x12,
0x33,
0x33,
0x11,
0x21,
0x12,
0x33,
0x21,
0x33,
0x33,
0x11,
0x34,
0x21,
0x34,
0x14,
0x33,
0x31,
0x33,
0x23,
0x31,
0x33,
0x23,
0x31,
0x11,
0x32,
0x43,
0x22,
0x12,
0x22,
0x33,
0x31,
0x33,
0x34,
0x33,
0x33,
0x13,
0x33,
0x13,
0x33,
0x42,
0x44,
0x44,
0x24,
0x34,
0x11,
0x33,
0x33,
0x33,
0x33,
0x13,
0x33,
0x12,
0x33,
0x13,
0x32,
0x33,
0x33,
0x33,
0x33,
0x13,
0x02,
};

#define MAX_APPLET_NAME_LEN 17
